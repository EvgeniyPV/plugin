<?php
namespace Automattic\Jetpack_Boost\Contracts;

interface Has_Slug {
	public function get_slug();
}
