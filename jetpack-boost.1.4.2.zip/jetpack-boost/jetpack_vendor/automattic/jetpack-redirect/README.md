# Jetpack Redirect package

A package containing functionality to generate URLs to the jetpack.com/redirect/ service

### Usage TODO

See `Automattic\Jetpack\Redirect::get_url()` documentation.

### Testing

```bash
$ composer run phpunit
```
