# plugins-installer

Handle installation of plugins from WP.org

## How to install plugins-installer

### Installation From Git Repo

## Contribute

## Get Help

## Security

Need to report a security vulnerability? Go to [https://automattic.com/security/](https://automattic.com/security/) or directly to our security bug bounty site [https://hackerone.com/automattic](https://hackerone.com/automattic).

## License

plugins-installer is licensed under [GNU General Public License v2 (or later)](./LICENSE.txt)

